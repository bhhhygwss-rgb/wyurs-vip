﻿<?php session_start(); $u=$_SESSION["username"]??"admin"; ?>
<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><title>Profil â€” Daltonlar</title>
<style>body{background:#0a0a0f;color:#eee;font-family:sans-serif;margin:0;display:flex}.side{width:240px;background:#0f0f14;padding:20px;min-height:100vh;border-right:1px solid #eab308}.main{padding:24px;flex:1}a{color:#eab308;text-decoration:none;display:block;padding:8px 0}.card{background:#12121a;padding:16px;border-radius:10px;margin-top:16px}</style></head>
<body>
<div class="side"><b><?=htmlspecialchars($u)?></b><a href="../dashboard.php">Ana Sayfa</a><a href="../tcsorgu.php">TC Sorgu</a><a href="../logout.php">Ã‡Ä±kÄ±ÅŸ</a></div>
<div class="main"><h2>Profil</h2><div class="card"><p>KullanÄ±cÄ±: <?=htmlspecialchars($u)?></p><p>VIP Aktif</p></div></div>
<script src="../snow.js"></script></body></html>


