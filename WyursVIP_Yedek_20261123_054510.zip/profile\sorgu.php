<?php header("Location: ../tcsorgu.php"); exit; ?>
